import { Routes } from '@angular/router';
import { DashboardComponent } from './dashboard.component';

export const routes: Routes = [
  {
    path: '',
    component: DashboardComponent,
    children: [
      { path:'crear-pacientes', loadComponent: () => import('./pacientes/crear-paciente/crear-paciente.component').then(m => m.CrearPacienteComponent) },
      { path:'lista-pacientes', loadComponent: () => import('./pacientes/lista-paciente/lista-paciente.component').then(m => m.ListaPacienteComponent) },
      { path:'crear-historial', loadComponent: () => import('./historial/crear-historial/crear-historial.component').then(m => m.CrearHistorialComponent) },
      { path:'lista-historial', loadComponent: () => import('./historial/lista-historial/lista-historial.component').then(m => m.ListaHistorialComponent) },
      { path: '', redirectTo: '/crear-pacientes', pathMatch: 'full' },

    ]

  }
];
